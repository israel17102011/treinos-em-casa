# Treinos em Casa

Site pronto para deploy. Coloque os arquivos no root do repositório e ative GitHub Pages (branch main, /root).